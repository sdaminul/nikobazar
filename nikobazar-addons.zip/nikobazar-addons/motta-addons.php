<?php
/**
 * Plugin Name: Nikobazar Addons
 * Plugin URI: https://nikobazar.com
 * Description: Premium modules and extra elements for Elementor, specifically designed for the Nikobazar theme.
 * Version: 1.4.6
 * Author: NikoBazar Theme
 * Author URI: https://nikobazar.com
 * License: GPL2+
 * Text Domain: nikobazar-addons
 * Domain Path: lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'MOTTA_ADDONS_VER' ) ) {
	define( 'MOTTA_ADDONS_VER', '1.4.6' );
}

if ( ! defined( 'MOTTA_ADDONS_DIR' ) ) {
	define( 'MOTTA_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'MOTTA_ADDONS_URL' ) ) {
	define( 'MOTTA_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once MOTTA_ADDONS_DIR . 'plugin.php';

\Nikobazar\Addons::instance();