jQuery( document ).ready( function( $ ) {
	$( '.nikobazar-size-guide-tabs' ).on( 'click', '.nikobazar-size-guide-tabs__nav li', function() {
        var $tab = $( this ),
            index = $tab.data( 'target' ),
            $panels = $tab.closest( '.nikobazar-size-guide-tabs' ).find( '.nikobazar-size-guide-tabs__panels' ),
            $panel = $panels.find( '.nikobazar-size-guide-tabs__panel[data-panel="' + index + '"]' );

        if ( $tab.hasClass( 'active' ) ) {
            return;
        }

        $tab.addClass( 'active' ).siblings( 'li.active' ).removeClass( 'active' );

        if ( $panel.length ) {
            $panel.addClass( 'active' ).siblings( '.nikobazar-size-guide-tabs__panel.active' ).removeClass( 'active' );
        }
    } );
} );