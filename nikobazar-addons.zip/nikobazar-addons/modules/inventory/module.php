<?php
/**
 * Nikobazar Addons Modules functions and definitions.
 *
 * @package Nikobazar
 */

namespace Nikobazar\Addons\Modules\Inventory;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Module {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Nikobazar\Addons\Auto_Loader::register( [
			'Nikobazar\Addons\Modules\Inventory\Settings'   => MOTTA_ADDONS_DIR . 'modules/inventory/settings.php',
			'Nikobazar\Addons\Modules\Inventory\Frontend'   => MOTTA_ADDONS_DIR . 'modules/inventory/frontend.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		if ( is_admin() ) {
			\Nikobazar\Addons\Modules\Inventory\Settings::instance();
		}

		\Nikobazar\Addons\Modules\Inventory\Frontend::instance();
	}

}
