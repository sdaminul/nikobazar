jQuery( document ).ready( function( $ ) {
	'use strict';

	var wp = window.wp,
		data = {},
		$body = $( document.body ),
		template = wp.template( 'nikobazar-icon-box' );

	// Toggle a filter's fields.
	$body.on( 'click', '.nikobazar-icon-box__field-top', function( event ) {
		event.preventDefault();

		$( this )
			.closest( '.nikobazar-icon-box__field' )
			.toggleClass( 'open' )
			.children( '.nikobazar-icon-box__field-options' )
			.toggle();
	} );

	// Add a new filter.
	$body.on( 'click', '.nikobazar-icon-box__add-new', function( event ) {
		event.preventDefault();

		var $button = $( this ),
			$box = $button.closest( '.nikobazar-icon-box__section' ).children( '.nikobazar-icon-box__fields' ),
			$title = $button.closest( '.widget-content' ).find( 'input' ).first();

		data.name = $button.data( 'name' );
		data.count = $button.data( 'count' );

		$button.data( 'count', data.count + 1 );
		$box.append( template( data ) );
		$box.trigger( 'runColor' );
		$title.trigger( 'change' ); // Support customize preview.
	} );

	// Remove a filter.
	$body.on( 'click', '.nikobazar-icon-box__remove', function( event ) {
		event.preventDefault();

		var $button = $( this ),
			$boxs = $button.closest( '.nikobazar-icon-box__fields' );

		$button
			.closest( '.nikobazar-icon-box__field' )
			.hide()
			.remove();

		$boxs
			.closest( '.widget-content' )
			.find( 'input' )
			.first()
			.trigger( 'change' );
	});

	// Live update for the title.
	$body.on( 'input', '.nikobazar-icon-box__field-option[data-option="box:text"] input', function() {
		$( this ).closest( '.nikobazar-icon-box__field' ).find( '.nikobazar-icon-box__field-title' ).text( this.value );
	} );

	// ColorPicker
	function initColorPicker( widget ) {
		widget?.find( '.nikobazar-color-widget' ).wpColorPicker();
	}

	function onUpdate( event, widget ) {
		initColorPicker( widget );
	}

	$( document ).on( 'widget-added widget-updated runColor', onUpdate );

	$( '.widget', '.wp-block-legacy-widget' ).each( function () {
		initColorPicker( $( this ) );
	} );

	$body.on( 'runColor', function() {
		$( '.widget', '.wp-block-legacy-widget' ).each( function () {
			initColorPicker( $( this ).find( '.nikobazar-icon-box__section' ) );
		} );
	} );
} );
