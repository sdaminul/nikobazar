<?php
namespace Nikobazar\Addons\Elementor\Builder\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Archive_Page_Header extends Widget_Base {
	public function get_name() {
		return 'nikobazar-archive-page-header';
	}

	public function get_title() {
		return esc_html__( '[Nikobazar] Archive Page Header', 'nikobazar-addons' );
	}

	public function get_icon() {
		return 'eicon-header';
	}

	public function get_categories() {
		return ['nikobazar-wc-addons'];
	}

	public function get_keywords() {
		return [ 'woocommerce', 'title', 'archive', 'page header', 'description' ];
	}

	public function get_style_depends() {
		return [ 'nikobazar-product-archive' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			[ 'label' => esc_html__( 'Page Header', 'nikobazar-addons' ) ]
		);

		$this->add_control(
			'type',
			[
				'label'     => esc_html__( 'Type', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'standard',
				'options'   => [
					'standard'   => esc_html__( 'Standard (image and text)', 'nikobazar-addons' ),
					'minimal' => esc_html__( 'Minimal (text only)', 'nikobazar-addons' ),
				],
			]
		);

		$this->add_responsive_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'nikobazar-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
				],
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__image' => 'background-image: url("{{URL}}");',
				],
				'condition'   => [
					'type' => 'standard',
				],
			]
		);

		$this->add_responsive_control(
			'background_position',
			[
				'label'     => esc_html__( 'Background Position', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'responsive' => true,
				'options'   => [
					''              => esc_html__( 'Default', 'nikobazar-addons' ),
					'left top'      => esc_html__( 'Left Top', 'nikobazar-addons' ),
					'left center'   => esc_html__( 'Left Center', 'nikobazar-addons' ),
					'left bottom'   => esc_html__( 'Left Bottom', 'nikobazar-addons' ),
					'right top'     => esc_html__( 'Right Top', 'nikobazar-addons' ),
					'right center'  => esc_html__( 'Right Center', 'nikobazar-addons' ),
					'right bottom'  => esc_html__( 'Right Bottom', 'nikobazar-addons' ),
					'center top'    => esc_html__( 'Center Top', 'nikobazar-addons' ),
					'center center' => esc_html__( 'Center Center', 'nikobazar-addons' ),
					'center bottom' => esc_html__( 'Center Bottom', 'nikobazar-addons' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__image' => 'background-position: {{VALUE}};',
				],
				'condition'   => [
					'type' => 'standard',
				],
			]
		);

		$this->add_responsive_control(
			'background_repeat',
			[
				'label'     => esc_html__( 'Background Repeat', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'no-repeat',
				'options'   => [
					'no-repeat' => esc_html__( 'No-repeat', 'nikobazar-addons' ),
					'repeat' 	=> esc_html__( 'Repeat', 'nikobazar-addons' ),
					'repeat-x'  => esc_html__( 'Repeat-x', 'nikobazar-addons' ),
					'repeat-y'  => esc_html__( 'Repeat-y', 'nikobazar-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__image' => 'background-repeat: {{VALUE}}',
				],
				'condition'   => [
					'type' => 'standard',
				],
			]
		);

		$this->add_responsive_control(
			'background_size',
			[
				'label'     => esc_html__( 'Background Size', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'cover',
				'options'   => [
					'cover'   => esc_html__( 'Cover', 'nikobazar-addons' ),
					'contain' => esc_html__( 'Contain', 'nikobazar-addons' ),
					'auto'    => esc_html__( 'Auto', 'nikobazar-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__image' => 'background-size: {{VALUE}}',
				],
				'condition'   => [
					'type' => 'standard',
				],
			]
		);

		$this->add_control(
			'background_overlay',
			[
				'label' => __( 'Background Overlay', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__image-overlay' => 'background-color: {{VALUE}}',
				],
				'condition'   => [
					'type' => 'standard',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__image' => 'background-color: {{VALUE}}',
				],
				'condition'   => [
					'type' => 'standard',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'     => esc_html__( 'Height', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'desktop_default' => [
					'size' => 260,
					'unit' => 'px',
				],
				'range'     => [
					'px' => [
						'min' => 10,
						'max' => 600,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__content' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'type' => 'standard',
				],
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'nikobazar-addons' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_page_header_style',
			[
				'label' => esc_html__( 'Page Header', 'nikobazar-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label' => esc_html__( 'Title', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .page-header .page-header__title',
			]
		);

		$this->add_control(
			'desc_heading',
			[
				'label' => esc_html__( 'Description', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'hide_desc',
			[
				'label' => esc_html__( 'Hide', 'nikobazar-addons' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'nikobazar-addons' ),
				'label_off' => esc_html__( 'No', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__description' => 'display: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'desc_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 600,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__description' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .page-header .page-header__description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',
				'selector' => '{{WRAPPER}} .page-header .ppage-header__description',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$atts = $this->taxonomy_fields();
		$image_style = $atts && isset( $atts['bg_image'] ) ? 'style=background-image:url(' . $atts['bg_image'] . ')' : '';
		$overlay_style = $atts && isset( $atts['bg_overlay'] ) ? 'style=' . $atts['bg_overlay']  : '';
		$page_header_style = $atts && isset( $atts['color'] ) ? 'style=--nikobazar-text-color:' . isset( $atts['color'] ) : '';

		?>
		<div class="page-header page-header-elementor page-header--products page-header--<?php echo esc_attr( $settings['align'] );?> page-header--<?php echo esc_attr( $settings['type'] ); ?>" <?php echo esc_attr( $page_header_style ) ?>>
			<div class="page-header__content">
				<?php if( $settings['type'] == 'standard' ) { ?>
				<div class="page-header__image" <?php echo esc_attr( $image_style ) ?>>
					<div class="page-header__image-overlay" <?php echo esc_attr( $overlay_style ) ?>></div>
				</div>
				<?php } ?>
				<?php echo apply_filters('nikobazar_page_header_title', '<h1 class="page-header__title">' . get_the_archive_title() . '</h1>');  ?>
				<?php $this->description(); ?>
			</div>
		</div>
		<?php
	}

	public function render_plain_content() {}

	public function get_group_name() {
		return 'woocommerce';
	}

	/**
	 * Get description
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function description() {
		ob_start();
		if( function_exists('is_shop') && is_shop() ) {
			woocommerce_product_archive_description();
		}

		$description = ob_get_clean();

		if ( is_tax() ) {
			$term = get_queried_object();
			if ( $term ) {
				$description = $term->description;
			}
		}

		if( $description ) {
			echo '<div class="page-header__description">'. $description .'</div>';
		}
	}

	/**
	 * Get description
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function taxonomy_fields() {
		$atts = array();
		if ( ! is_product_taxonomy() ) {
			return $atts;
		}

		$term_id  = get_queried_object_id();
		$image_id                                     = absint( get_term_meta( $term_id, 'nikobazar_page_header_bg_id', true ) );
		$nikobazar_page_header_background_overlay         = get_term_meta( $term_id, 'nikobazar_page_header_background_overlay', true );
		$nikobazar_page_header_background_overlay_opacity = get_term_meta( $term_id, 'nikobazar_page_header_background_overlay_opacity', true );

		$nikobazar_page_header_textcolor                  = get_term_meta( $term_id, 'nikobazar_page_header_textcolor', true );
		$nikobazar_page_header_textcolor_custom           = get_term_meta( $term_id, 'nikobazar_page_header_textcolor_custom', true );

		if ( $nikobazar_page_header_textcolor == 'custom' ) {
			$atts['color']          = $nikobazar_page_header_textcolor_custom;
		} elseif ( $nikobazar_page_header_textcolor == 'dark' ) {
			$atts['color']         = '#000';
		} elseif ( $nikobazar_page_header_textcolor == 'light' ) {
			$atts['color']         = '#fff';
		}

		if ( $image_id ) {
			$image             = wp_get_attachment_image_src( $image_id, 'full' );
			if( $image ) {
				$atts['bg_image'] = $image[0];
			}
		}
		$bg_overlay = '';
		if ( $nikobazar_page_header_background_overlay ) {
			$bg_overlay = 'background-color:' . $nikobazar_page_header_background_overlay;
		}

		if( $nikobazar_page_header_background_overlay_opacity ) {
			$bg_overlay .= ';opacity:' . $nikobazar_page_header_background_overlay_opacity;
		}

		$atts['bg_overlay'] = $bg_overlay;

		return $atts;
	}
}
