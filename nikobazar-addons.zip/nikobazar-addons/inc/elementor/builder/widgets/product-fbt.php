<?php
namespace Nikobazar\Addons\Elementor\Builder\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Product_FBT extends Widget_Base {

	use \Nikobazar\Addons\Elementor\Builder\Traits\Product_Id_Trait;

	public function get_name() {
		return 'nikobazar-wc-product-fbt';
	}

	public function get_title() {
		return esc_html__( '[Nikobazar] Product Frequently Bought Together', 'nikobazar-addons' );
	}

	public function get_icon() {
		return 'eicon-woocommerce';
	}

	public function get_keywords() {
		return [ 'woocommerce', 'shop', 'store', 'frequently', 'bought', 'together' ];
	}

	public function get_categories() {
		return [ 'nikobazar-wc-addons' ];
	}

	public function get_style_depends() {
		return [ 'nikobazar-elementor-single-product' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_heading_style',
			[
				'label' => esc_html__( 'Heading', 'nikobazar-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'selector' => '.woocommerce {{WRAPPER}} .nikobazar-product-pbt__title',
			]
		);

		$this->add_responsive_control(
			'heading_text_align',
			[
				'label' => esc_html__( 'Text Align', 'nikobazar-addons' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt__title' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'heading_spacing',
			[
				'label' => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt__title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_product_style',
			[
				'label' => esc_html__( 'Product', 'nikobazar-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'product_padding',
			[
				'label' => esc_html__( 'Padding', 'nikobazar-addons' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt ul.products .product-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'product_border_color',
			[
				'label' => esc_html__( 'Border Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt ul.products .product-content' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_total_price_style',
			[
				'label' => esc_html__( 'Total Price', 'nikobazar-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'total_price_heading_style',
			[
				'label' => esc_html__( 'Heading', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'total_price_heading_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'total_price_heading_typography',
				'selector' => '.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__title',
			]
		);

		$this->add_responsive_control(
			'total_price_heading_spacing',
			[
				'label' => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'total_price_sub_total_style',
			[
				'label' => esc_html__( 'Sub Total', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'total_price_sub_total_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'total_price_sub_total_typography',
				'selector' => '.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__subtotal .label, .woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__subtotal .s-price',
			]
		);

		$this->add_responsive_control(
			'total_price_sub_total_spacing',
			[
				'label' => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__subtotal' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'total_price_save_style',
			[
				'label' => esc_html__( 'Save', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'total_price_save_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__save' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'total_price_save_typography',
				'selector' => '.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__save .label, .woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__save .s-price',
			]
		);

		$this->add_responsive_control(
			'total_price_save_spacing',
			[
				'label' => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__save' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'total_price_total_style',
			[
				'label' => esc_html__( 'Total', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'total_price_total_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__total' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'total_price_total_typography',
				'selector' => '.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__total .label, .woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .price-box__total .s-price',
			]
		);

		$this->add_control(
			'total_price_button_style',
			[
				'label' => esc_html__( 'Button', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'total_price_button_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .nikobazar-pbt-add-to-cart' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'total_price_button_color',
			[
				'label' => esc_html__( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .nikobazar-pbt-add-to-cart' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'total_price_button_typography',
				'selector' => '.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .nikobazar-pbt-add-to-cart',
			]
		);

		$this->add_responsive_control(
			'total_price_button_spacing',
			[
				'label' => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'selectors' => [
					'.woocommerce {{WRAPPER}} .nikobazar-product-pbt .product-buttons .nikobazar-pbt-add-to-cart' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);


		$this->end_controls_section();

	}


	protected function render() {
		global $product;

		$product = $this->get_product();

		if ( ! $product ) {
			return;
		}

		do_action('nikobazar_single_product_fbt_element');

	}

	public function render_plain_content() {}

	public function get_group_name() {
		return 'woocommerce';
	}
}
