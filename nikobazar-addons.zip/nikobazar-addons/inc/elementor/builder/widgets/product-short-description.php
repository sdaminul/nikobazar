<?php
namespace Nikobazar\Addons\Elementor\Builder\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Product_Short_Description extends Widget_Base {

	use \Nikobazar\Addons\Elementor\Builder\Traits\Product_Id_Trait;

	public function get_name() {
		return 'nikobazar-wc-product-short-description';
	}

	public function get_title() {
		return esc_html__( '[Nikobazar] Product Short Description', 'nikobazar-addons' );
	}

	public function get_icon() {
		return 'eicon-product-description';
	}

	public function get_categories() {
		return ['nikobazar-wc-addons'];
	}

	public function get_keywords() {
		return [ 'woocommerce', 'shop', 'store', 'short description', 'description', 'product' ];
	}

	public function get_script_depends() {
		return [
			'nikobazar-elementor-single-product'
		];
	}

	public function get_style_depends() {
		return [ 'nikobazar-elementor-single-product' ];
	}

	/**
	 * Register heading widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.1.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_desc',
			[
				'label' => esc_html__( 'Product Description', 'nikobazar-addons' ),
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'nikobazar-addons' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Features', 'nikobazar' ),
				'default' => __( 'Features', 'nikobazar' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'nikobazar-addons' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'description_lines',
			[
				'label'              => esc_html__( 'Product Description Lines', 'nikobazar-addons' ),
				'description' => esc_html__('This option does not work with the nikobazar_more shortcode', 'nikobazar-addons'),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 50,
				'default'            => 6,
				'selectors' => [
					'.woocommerce {{WRAPPER}} .short-description' => '--mt-product-description-lines: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_description_style',
			[
				'label' => esc_html__( 'Product Description', 'nikobazar-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Text Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product_title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'selector' => '{{WRAPPER}} .product_title',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render heading widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		global $product;

		$product = $this->get_product();

		if ( ! $product ) {
			return;
		}

		$content = $product->get_short_description();
		if( empty( $content ) ) {
			return;
		}
		$title = $settings['title'];
		$title = $title ? sprintf('<label class="short-description__label">%s</label>', $title ) : '';
		echo '<div class="short-description">';
		echo $title;
		if( has_shortcode( $content, 'nikobazar_more' ) ) {
				echo wp_kses_post( do_shortcode( $content ) );
		} else {
			$option = array(
				'more'   => esc_html__( 'Show More', 'nikobazar' ),
				'less'   => esc_html__( 'Show Less', 'nikobazar' )
			);

			echo sprintf('<div class="short-description__content">%s</div>',  wp_kses_post( $content ));
			echo sprintf('
				<button class="short-description__more nikobazar-button--subtle nikobazar-button--color-black" data-settings="%s">%s</button>',
				htmlspecialchars(json_encode( $option )),
				esc_html__('Show More', 'nikobazar')
			);
		}
		echo '</div>';
	}
}
