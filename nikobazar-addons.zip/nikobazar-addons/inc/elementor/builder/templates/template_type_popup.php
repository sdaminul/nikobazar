<?php
/**
 * The Template for displaying all template type
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div id="nikobazar-builder-template-modal" class="nikobazar-builder-template-modal">
	<div class="modal__backdrop"></div>
	<div class="modal__content">
		<span class="nikobazar-svg-icon nikobazar-svg-icon--close modal__button-close"><svg width="24" height="24" aria-hidden="true" role="img" focusable="false" viewBox="0 0 32 32"><path d="M28.336 5.936l-2.272-2.272-10.064 10.080-10.064-10.080-2.272 2.272 10.080 10.064-10.080 10.064 2.272 2.272 10.064-10.080 10.064 10.080 2.272-2.272-10.080-10.064z"></path></svg></span>
		<form class="modal-content__form" action="<?php echo esc_url( admin_url('post.php') ); ?>">
			<input type="hidden" class="_wpnonce" value="<?php echo wp_create_nonce( 'nikobazar_buider_new_template' ); ?>">
			<div class="modal-content-form__title"><?php echo esc_html__( 'Choose Template Type', 'nikobazar-addons' ); ?></div>
			<div  class="elementor-form-field">
				<label for="nikobazar-builder-template-modal-type" class="elementor-form-field__label"><?php echo esc_html__( 'Select the type of template you want to work on', 'nikobazar-addons' ); ?></label>
				<select id="nikobazar-builder-template-modal-type" class="elementor-form-field__select" required>
					<option value="product"><?php echo esc_html__( 'Single Product', 'nikobazar-addons' ); ?></option>
					<option value="product_archive"><?php echo esc_html__( 'Product Archive', 'nikobazar-addons' ); ?></option>
				</select>
			</div>
			<div class="elementor-form-field">
				<label for="nikobazar-builder-template-modal__post-title" class="elementor-form-field__label">
					<?php echo esc_html__( 'Name your template', 'nikobazar-addons' ); ?>
				</label>
				<input type="text" placeholder="<?php echo esc_attr__( 'Enter template name (optional)', 'nikobazar-addons' ); ?>" required id="nikobazar-builder-template-modal__post-title" class="elementor-form-field__text">
			</div>
			<div class="elementor-form-field">
				<input class="elementor-form-field__checkbox" type="checkbox" name="woolentor-template-default" id="nikobazar-builder-template-modal__post-default">
				<label for="nikobazar-builder-template-modal__post-default" class="elementor-form-field__label">
					<?php echo esc_html__( 'Set Default', 'nikobazar-addons' ); ?>
				</label>
			</div>
			<button id="nikobazar-builder-template-modal__submit" class="elementor-button e-primary"><span><?php echo esc_html__( 'Create Template', 'nikobazar-addons' ); ?></span></button>
			<p class="modal-content-form-message"></p>
		</form>
	</div>
</div>
