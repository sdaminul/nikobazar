<?php
namespace Nikobazar\Addons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Preferences widget
 */
class Preferences extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nikobazar-preferences';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Nikobazar] Preferences', 'nikobazar-addons' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-globe';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['nikobazar-addons'];
	}

	/**
	 * Get widget keywords.
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'preferences', 'currency', 'language', 'nikobazar-addons', 'nikobazar-addons' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	protected function section_content() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Preferences', 'nikobazar-addons' ),
			]
		);

		$this->add_control(
			'language',
			[
				'label'     => esc_html__( 'Language', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'currency',
			[
				'label'     => esc_html__( 'Currency', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();
	}

	// Tab Style
	protected function section_style() {
		$this->start_controls_section(
			'section_style',
			[
				'label'     => __( 'Preferences', 'nikobazar-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'nikobazar-addons' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'nikobazar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-preferences--elementor' => 'justify-content: {{VALUE}};text-align:{{VALUE}}',
				],
			]
		);

		$this->add_control(
			'heading_language',
			[
				'label' => __( 'Language', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'flag',
			[
				'label' => esc_html__( 'Show Flag', 'nikobazar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Hide', 'nikobazar-addons' ),
				'label_off' => esc_html__( 'Show', 'nikobazar-addons' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);

		$this->add_control(
			'language_color',
			[
				'label' => __( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-language' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'language_spacing',
			[
				'label' => __( 'Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-language .nikobazar-button__icon + .nikobazar-button__text' => 'padding-left: {{size}}{{UNIT}} ;',
				],
			]
		);

		$this->add_control(
			'heading_currency',
			[
				'label' => __( 'Currency', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'currency_color',
			[
				'label' => __( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-currency' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'currency_spacing',
			[
				'label' => __( 'Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-currency .nikobazar-button__icon + .nikobazar-button__text' => 'padding-left: {{size}}{{UNIT}} ;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?><div class="nikobazar-preferences nikobazar-preferences--elementor"><?php
		$languages    = \Nikobazar\Helper::language_status();

		if ( ! empty( $languages ) && ! empty( $settings['language'] ) ) {
			\Nikobazar\Theme::set_prop( 'modals', 'preferences' );

			foreach ( (array) $languages as $key => $language ) {
				if( $language['active'] ) {
					$name = $language['native_name'];

					if( $settings['flag'] ) {
						$flag = $language['country_flag_url'];
					}
				} else {
					$key = key($languages);
					$name = $languages[$key]['native_name'];

					if( $settings['flag'] ) {
						$flag = $languages[$key]['country_flag_url'];
					}
				}
			}
			?>
			<div class="nikobazar-language nikobazar-preferences__item">
				<a href="#" data-toggle="modal" data-target="preferences-modal" class="nikobazar-button nikobazar-button--text nikobazar-button--color-black">
					<span class="nikobazar-button__icon">
						<?php if( empty( $flag ) ) : ?>
							<?php echo \Nikobazar\Addons\Helper::get_svg( esc_attr( 'language' ) ); ?>
						<?php else : ?>
							<img src="<?php echo esc_url( $flag ); ?>" width="16" height="16" alt="<?php echo esc_html( $name ); ?>" />
						<?php endif; ?>
					</span>
					<span class="nikobazar-button__text">
						<?php echo esc_html( $name ); ?>
					</span>
				</a>
			</div>
			<?php
		}

		$args = \Nikobazar\Helper::currency_status();

		if( ! empty( $args ) && ! empty( $settings['currency'] ) ) {

			\Nikobazar\Theme::set_prop( 'modals', 'preferences' );

			$symbol_currency = $args['symbol_currency'];
			$current_currency = $args['current_currency'];

			?>
			<div class="nikobazar-currency nikobazar-preferences__item">
				<a href="#" data-toggle="modal" data-target="preferences-modal" class="nikobazar-button nikobazar-button--text nikobazar-button--color-black">
					<span class="nikobazar-button__icon">
						<?php echo \Nikobazar\Addons\Helper::get_svg( esc_attr( 'currency' ) ); ?>
					</span>
					<span class="nikobazar-button__text">
						<?php echo esc_html( $symbol_currency ) . ' - ' . esc_html( $current_currency ); ?>
					</span>
				</a>
			</div>
			<?php
		}

		?></div><?php
	}
}