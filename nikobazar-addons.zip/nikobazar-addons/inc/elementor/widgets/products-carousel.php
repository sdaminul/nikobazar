<?php
namespace Nikobazar\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Nikobazar\Addons\Elementor\Base\Products_Widget_Base;
use Elementor\Controls_Stack;
use Elementor\Icons_Manager;
use Nikobazar\Addons\Elementor;
use Nikobazar\Addons\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Products Carousel
 */
class Products_Carousel extends Products_Widget_Base {
	use \Nikobazar\Addons\Elementor\Widgets\Traits\Button_Trait;

	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nikobazar-products-carousel';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Nikobazar] Products Carousel', 'nikobazar-addons' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-carousel';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['nikobazar-addons'];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'products carousel', 'products', 'carousel', 'woocommerce', 'nikobazar-addons' ];
	}

	public function get_script_depends() {
		return [
			'nikobazar-coundown',
			'nikobazar-elementor-widgets'
		];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_content_products();
		$this->section_content_carousel();
	}

	protected function section_content_products() {
		$this->start_controls_section(
			'section_products',
			[
				'label' => __( 'Products', 'nikobazar-addons' ),
			]
		);

		$this->register_products_controls( 'all' );

		$this->add_control(
			'attributes_divider',
			[
				'label' => esc_html__( 'Attributes', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'hide_category',
			[
				'label'     => esc_html__( 'Hide Category', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .meta-wrapper' => 'display: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'hide_rating',
			[
				'label'     => esc_html__( 'Hide Rating', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .nikobazar-rating' => 'display: {{VALUE}}',
					'{{WRAPPER}} ul.products.product-card-layout-3 li.product.swiper-slide-visible:before ' => 'height: calc( 100% - 25px );',
					'{{WRAPPER}} ul.products.product-card-layout-4 li.product .product-inner:hover .nikobazar-rating + .product-actions' => 'transform: none;',
				],
			]
		);

		$this->add_control(
			'hide_attributes',
			[
				'label'     => esc_html__( 'Hide Attributes', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .product-variation-items' => 'display: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'hide_badge',
			[
				'label'     => esc_html__( 'Hide Badge', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .woocommerce-badges' => 'display: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'hide_featured_icons',
			[
				'label'     => esc_html__( 'Hide Featured Icons', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .product-thumbnail .product-featured-icons' => 'display: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'hide_buttons',
			[
				'label'     => esc_html__( 'Hide Featured Buttons', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products:not(.product-card-layout-6) li.product .product-actions' => 'display: {{VALUE}}',
					'{{WRAPPER}} ul.products.product-card-layout-6 li.product .product-actions > a.button' => 'display: {{VALUE}}',
				],
				'prefix_class' => 'nikobazar-product-carousel__hide-featured-buttons-',
			]
		);

		$this->add_control(
			'hide_vendor',
			[
				'label'     => esc_html__( 'Hide Vendor Name', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .sold-by-meta' => 'display: {{VALUE}}',
				],
			]
		);

		$this->section_content_heading();

		$this->end_controls_section();
	}

	protected function section_content_heading() {
		$this->add_control(
			'heading_block',
			[
				'label' => __( 'Heading Block', 'nikobazar-addons' ),
				'description' => __( 'Add a heading block as the the first item', 'nikobazar-addons' ),
				'type' => Controls_Manager::SWITCHER,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_type',
			[
				'label'       => esc_html__( 'Title Type', 'nikobazar-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'text'   => esc_html__( 'Text', 'nikobazar-addons' ),
					'svg' 	 => esc_html__( 'SVG Icon', 'nikobazar-addons' ),
					'image'  => esc_html__( 'Image', 'nikobazar-addons' ),
					'external' 	=> esc_html__( 'External', 'nikobazar-addons' ),
				],
				'default' => 'text',
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'nikobazar-addons' ),
				'type'    => Controls_Manager::TEXT,
				'conditions' => [
					'terms' => [
						[
							'name'  => 'heading_block',
							'value' => 'yes',
						],
						[
							'name'  => 'title_type',
							'value' => 'text',
						],
					],
				],
			]
		);

		$this->add_control(
			'title_icon',
			[
				'label' => __( 'Title', 'nikobazar-addons' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-star',
					'library' => 'fa-solid',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'heading_block',
							'value' => 'yes',
						],
						[
							'name'  => 'title_type',
							'value' => 'svg',
						],
					],
				],
			]
		);

		$this->add_control(
			'title_image',
			[
				'label' => __( 'Title', 'nikobazar-addons' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'heading_block',
							'value' => 'yes',
						],
						[
							'name'  => 'title_type',
							'value' => 'image',
						],
					],
				],
			]
		);

		$this->add_control(
			'external_url',
			[
				'label' => esc_html__( 'External URL', 'nikobazar-addons' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'title_type',
							'value' => 'external',
						],
					],
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'   => esc_html__( 'Description', 'nikobazar-addons' ),
				'type'    => Controls_Manager::TEXTAREA,
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$controls = [
			'button_text_label' => __( 'Button Text', 'nikobazar-addons' ),
			'button_text_label_mobile'     => __( 'Button Text Mobile', 'nikobazar-addons'),
			'section_condition' => [
				'heading_block' => 'yes',
			]
		];

		$this->register_button_content_controls( $controls );
	}

	protected function section_content_carousel() {
		$this->start_controls_section(
			'section_products_carousel',
			[
				'label' => __( 'Carousel Settings', 'nikobazar-addons' ),
			]
		);

		$this->add_responsive_control(
			'slides_to_show',
			[
				'label'   => esc_html__( 'Slides to show', 'nikobazar-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'1'    => __( '1', 'nikobazar-addons' ),
					'2'    => __( '2', 'nikobazar-addons' ),
					'3'    => __( '3', 'nikobazar-addons' ),
					'4'    => __( '4', 'nikobazar-addons' ),
					'5'    => __( '5', 'nikobazar-addons' ),
					'6'    => __( '6', 'nikobazar-addons' ),
					'7'    => __( '7', 'nikobazar-addons' ),
					'auto' => __( 'Auto', 'nikobazar-addons' ),
				],
				'default'            => 5,
				'frontend_available' => true,
				'toggle'             => false,
				'separator'          => 'before',
			]
		);

		$this->add_responsive_control(
			'slides_width',
			[
				'label'     => __( 'Width', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => 0,
					],
					'%' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel ul.products li.product' => 'width: {{SIZE}}{{UNIT}} !important;',
				],
				'condition' => [
					'slides_to_show' => [ 'auto' ],
				],
				'required' => true,
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'label'              => esc_html__( 'Slides to scroll', 'nikobazar-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 1,
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'navigation',
			[
				'label'   => esc_html__( 'Navigation', 'nikobazar-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'arrows'           => esc_html__( 'Arrows', 'nikobazar-addons' ),
					'dots'             => esc_html__( 'Dots', 'nikobazar-addons' ),
					'scrollbar'        => esc_html__( 'Scrollbar', 'nikobazar-addons' ),
					'arrows-scrollbar' => esc_html__( 'Arrows & Scrollbar', 'nikobazar-addons' ),
					'arrows-dots' => esc_html__( 'Arrows & Dots', 'nikobazar-addons' ),
					'none'             => esc_html__( 'None', 'nikobazar-addons' ),
				],
				'default'            => 'arrows',
				'toggle'             => false,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'     => __( 'Autoplay', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'nikobazar-addons' ),
				'label_on'  => __( 'On', 'nikobazar-addons' ),
				'default'   => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'   => __( 'Autoplay Speed', 'nikobazar-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3000,
				'min'     => 100,
				'step'    => 100,
				'frontend_available' => true,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'   => __( 'Pause on Hover', 'nikobazar-addons' ),
				'type'    => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'nikobazar-addons' ),
				'label_on'  => __( 'On', 'nikobazar-addons' ),
				'default'   => 'yes',
				'frontend_available' => true,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'       => __( 'Animation Speed', 'nikobazar-addons' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 800,
				'min'         => 100,
				'step'        => 50,
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
	}

	// Tab Content
	protected function section_style() {
		$this->section_style_content();
		$this->section_style_carousel();
	}

	protected function section_style_content() {
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Products', 'nikobazar-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'show_border',
			[
				'label'        => esc_html__( 'Border between products', 'nikobazar-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => __( 'Hide', 'nikobazar-addons' ),
				'label_on'     => __( 'Show', 'nikobazar-addons' ),
				'return_value' => 'yes',
				'default'      => '',
				'prefix_class' => 'nikobazar-product-carousel__border-',
			]
		);

		$this->add_responsive_control(
			'border_height',
			[
				'label'     => __( 'Border Height', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}}.nikobazar-product-carousel__border-yes ul.products li.product' => '--nikobazar-product-carousel-border-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'show_border' => 'yes',
				],

			]
		);

		$this->add_responsive_control(
			'spaceBetween',
			[
				'label'     => __( 'Spacing between products', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} ul.products li.product' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .nikobazar-product-carousel.nikobazar-product-carousel__has-heading .swiper-container-initialized.woocommerce' => 'margin-left: -{{SIZE}}{{UNIT}}; margin-right: -{{SIZE}}{{UNIT}}; padding-left: 0; padding-right: 0;',
					'{{WRAPPER}} .nikobazar-product-carousel.nikobazar-product-carousel__has-heading .swiper-initialized.woocommerce' => 'margin-left: -{{SIZE}}{{UNIT}}; margin-right: -{{SIZE}}{{UNIT}}; padding-left: 0; padding-right: 0;',
					'{{WRAPPER}} .nikobazar-product-carousel.nikobazar-carousel-spacing-empty .swiper-container-initialized.woocommerce' => 'margin-left: -{{SIZE}}{{UNIT}}; margin-right: -{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .nikobazar-product-carousel.nikobazar-carousel-spacing-empty .swiper-initialized.woocommerce' => 'margin-left: -{{SIZE}}{{UNIT}}; margin-right: -{{SIZE}}{{UNIT}};',
				],

			]
		);

		$this->add_control(
			'heading_product_item',
			[
				'label' => __( 'Product Item', 'nikobazar-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'product_padding',
			[
				'label'      => esc_html__( 'Padding', 'nikobazar-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ul.products li.product .product-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'show_border' => '',
				],
			]
		);

		$this->add_responsive_control(
			'product_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'nikobazar-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ul.products li.product .product-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'show_border' => '',
				],
			]
		);

		$this->add_responsive_control(
			'product_featured_icons_spacing',
			[
				'label'      		=> esc_html__( 'Featured Icons Spacing', 'nikobazar-addons' ),
				'type'      		=> Controls_Manager::DIMENSIONS,
				'size_units' 		=> [ 'px', 'em', '%' ],
				'allowed_dimensions' => [ 'top', 'right' ],
				'selectors'  		=> [
					'{{WRAPPER}} ul.products:not(.product-card-layout-2) li.product .product-thumbnail .product-featured-icons' => 'top: {{TOP}}{{UNIT}}; right: {{RIGHT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'product_badge_spacing',
			[
				'label'      => esc_html__( 'Badge Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} ul.products li.product .woocommerce-badges' => 'top: {{SIZE}}{{UNIT}}; left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'product_item_padding',
			[
				'label'      => esc_html__( 'Summary Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} ul.products li.product .product-summary' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_button_padding',
			[
				'label'      => esc_html__( 'Buttons Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} ul.products li.product .product-actions' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'thumbnail_arrows_horizontal_spacing',
			[
				'label'      => esc_html__( 'Thumbnail Arrows Horizontal Spacing', 'nikobazar-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => -100,
						'max' => 1170,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ul.products li.product .product-thumbnails--slider .nikobazar-product-card-swiper-prev' => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} ul.products li.product .product-thumbnails--slider .nikobazar-product-card-swiper-next' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->section_style_heading();

		$this->end_controls_section();

	}

	protected function section_style_heading() {
		$this->add_control(
			'style_heading',
			[
				'label' => esc_html__( 'Heading', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'heading__text_align',
			[
				'label'       => esc_html__( 'Text Align', 'nikobazar-addons' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'nikobazar-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'nikobazar-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'nikobazar-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'     => 'center',
				'selectors'   => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading' => 'text-align: {{VALUE}}',
				],
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'heading_width',
			[
				'label'      => esc_html__( 'Max Width', 'nikobazar-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1900,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading' => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .nikobazar-product-carousel__has-heading > .swiper-container-initialized.woocommerce ' => 'max-width: calc( 100% - {{SIZE}}{{UNIT}} );',
					'{{WRAPPER}} .nikobazar-product-carousel__has-heading > .swiper-initialized.woocommerce ' => 'max-width: calc( 100% - {{SIZE}}{{UNIT}} );',
					'{{WRAPPER}} .nikobazar-product-carousel__has-heading > .nikobazar-product-carousel__container ' => 'max-width: calc( 100% - {{SIZE}}{{UNIT}} );',
					'(mobile){{WRAPPER}} .nikobazar-product-carousel__has-heading > .swiper-container-initialized.woocommerce ' => 'max-width: 100%;',
					'(mobile){{WRAPPER}} .nikobazar-product-carousel__has-heading > .swiper-initialized.woocommerce ' => 'max-width: 100%;',
					'(mobile){{WRAPPER}} .nikobazar-product-carousel__has-heading > .nikobazar-product-carousel__container ' => 'max-width: 100%;',
				],
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'heading_padding',
			[
				'label'      => esc_html__( 'Padding', 'nikobazar-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.nikobazar-rtl-smart {{WRAPPER}} .nikobazar-product-carousel__heading' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
				],
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_control(
			'heading_before_title',
			[
				'label'     => esc_html__( 'Title', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'      => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading-title' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'heading_block',
							'value' => 'yes',
						],
						[
							'name' => 'title_type',
							'operator' => '===',
							'value' => 'text'
						],
					]
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .nikobazar-product-carousel__heading-title--text, {{WRAPPER}} .nikobazar-product-carousel__heading-title--icon .nikobazar-svg-icon',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'heading_block',
							'value' => 'yes',
						],
						[
							'name' => 'title_type',
							'operator' => '===',
							'value' => 'text'
						],
					]
				]
			]
		);

		$this->add_responsive_control(
			'title_size',
			[
				'label' => __( 'Size', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading-title svg' => 'width: {{size}}{{UNIT}};height: auto;',
					'{{WRAPPER}} .nikobazar-product-carousel__heading-title img' => 'max-width: {{size}}{{UNIT}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'heading_block',
							'value' => 'yes',
						],
						[
							'name' => 'title_type',
							'operator' => '!==',
							'value' => 'text'
						],
					]
				]
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'(mobile){{WRAPPER}} .nikobazar-product-carousel__heading-title' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
				],
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_control(
			'heading_description',
			[
				'label'     => esc_html__( 'Description', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading-description' => 'color: {{VALUE}}',

				],
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .nikobazar-product-carousel__heading-description',
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'description_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel__heading-description' => 'margin-bottom: {{SIZE}}{{UNIT}}',
					'(mobile){{WRAPPER}} .nikobazar-product-carousel__heading-description' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
				],
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$this->add_control(
			'heading_buton',
			[
				'label'     => esc_html__( 'Button', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
				'condition' => [
					'heading_block' => 'yes',
				],
			]
		);

		$controls = [
			'button_text_label' => __( 'Button Text', 'nikobazar-addons' ),
			'size'      => 'medium',
			'section_condition' => [
				'heading_block' => 'yes',
			]
		];

		$this->register_button_style_controls($controls);
	}

	protected function section_style_carousel() {
		$this->start_controls_section(
			'section_style_carousel',
			[
				'label' => esc_html__( 'Carousel', 'nikobazar-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// Arrows
		$this->add_control(
			'arrow_style_heading',
			[
				'label' => esc_html__( 'Arrows', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'arrows_style',
			[
				'label'     => esc_html__( 'Arrows Style', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '1',
				'options'   => [
					'1'   	=> esc_html__( 'Style 1', 'nikobazar-addons' ),
					'2' 	=> esc_html__( 'Style 2', 'nikobazar-addons' ),
				],
				'prefix_class' => 'nikobazar-product-carousel__arrows-style-',
			]
		);

		$this->add_control(
			'arrows_icon',
			[
				'label'     => esc_html__( 'Icon Style', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'regular',
				'options'   => [
					'regular'   	=> esc_html__( 'Regular', 'nikobazar-addons' ),
					'thin' 	=> esc_html__( 'Thin', 'nikobazar-addons' ),
				],
			]
		);

		$this->add_control(
			'sliders_arrow_style',
			[
				'label'        => __( 'Option', 'nikobazar-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'nikobazar-addons' ),
				'label_on'     => __( 'Custom', 'nikobazar-addons' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			'sliders_arrows_size',
			[
				'label'     => __( 'Size', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_width',
			[
				'label'     => __( 'Width', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'default' => [ 'size' => 44, 'unit' => 'px' ],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_height',
			[
				'label'     => __( 'Height', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrows_radius',
			[
				'label'      => __( 'Border Radius', 'nikobazar-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrow_color',
			[
				'label'     => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrow_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'sliders_arrow_box_shadow',
				'label' => __( 'Box Shadow', 'nikobazar-addons' ),
				'selector' => '{{WRAPPER}} .nikobazar-swiper-button',
			]
		);

		$this->end_popover();

		$this->add_responsive_control(
			'sliders_arrows_horizontal_spacing',
			[
				'label'      => esc_html__( 'Horizontal Spacing', 'nikobazar-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => -100,
						'max' => 1170,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button-prev' => 'right: {{SIZE}}{{UNIT}}; left: auto;',
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button-next' => 'left: {{SIZE}}{{UNIT}}; right: auto;',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_vertical_spacing',
			[
				'label'      => esc_html__( 'Vertical Spacing', 'nikobazar-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1170,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .nikobazar-swiper-button' => 'top: {{SIZE}}{{UNIT}} ;',
				],
			]
		);

		// Dots
		$this->add_control(
			'dots_style_heading',
			[
				'label' => esc_html__( 'Dots', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sliders_dots_style',
			[
				'label'        => __( 'Option', 'nikobazar-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'nikobazar-addons' ),
				'label_on'     => __( 'Custom', 'nikobazar-addons' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			'sliders_dots_gap',
			[
				'label'     => __( 'Gap', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-pagination-bullet' => 'margin: 0 {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_dots_size',
			[
				'label'     => __( 'Size', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sliders_dot_item_color',
			[
				'label'     => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-pagination-bullet' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'sliders_dot_item_active_color',
			[
				'label'     => esc_html__( 'Color Active', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-pagination-bullet-active' => 'background-color : {{VALUE}};',
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-pagination-bullet:hover' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->end_popover();

		$this->add_responsive_control(
			'sliders_dots_vertical_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => 0,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		// Scrollbar
		$this->add_control(
			'scrollbar_style_heading',
			[
				'label' => esc_html__( 'Scrollbar', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'scrollbar_color',
			[
				'label'     => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-scrollbar' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'scrollbar_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-scrollbar-drag' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'scrollbar_width',
			[
				'label'     => __( 'Width', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'     => [
					'px' => [
						'max' => 1900,
						'min' => 0,
					],
					'%' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-scrollbar' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'scrollbar_spacing',
			[
				'label'     => __( 'Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 150,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-carousel--elementor .swiper-scrollbar' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$nav        = $settings['navigation'];
		$nav_tablet = empty( $settings['navigation_tablet'] ) ? $nav : $settings['navigation_tablet'];
		$nav_mobile = empty( $settings['navigation_mobile'] ) ? $nav : $settings['navigation_mobile'];

		$this->add_render_attribute( 'wrapper', 'class', [
			'nikobazar-products',
			'nikobazar-product-carousel',
			'nikobazar-product-carousel--elementor',
			'nikobazar-carousel--elementor',
			'nikobazar-swiper-carousel-elementor',
			'nikobazar-carousel--swiper',
			'navigation-' . $nav,
			'navigation-tablet-' . $nav_tablet,
			'navigation-mobile-' . $nav_mobile,
			'woocommerce',
			! empty( $settings['title'] ) || ! empty( $settings['description'] ) || ! empty( $settings['primary_button_link']['url'] ) ? 'nikobazar-product-carousel__has-heading' : '',
			! empty( $settings['hide_button'] ) ? 'product-no-button' : '',
		] );
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ) ?>>
			<?php if( ! empty( $settings['heading_block'] ) ) : ?>
				<div class="nikobazar-product-carousel__heading">

					<?php if( $settings['title_type'] == 'text' ) { ?>
						<?php if( ! empty( $settings['title'] ) ) : ?>
							<div class="nikobazar-product-carousel__heading-title nikobazar-product-carousel__heading-title--text"><?php echo $settings['title']; ?></div>
						<?php endif; ?>
					<?php } elseif ( $settings['title_type'] == 'image' ) { ?>
						<?php if( ! empty( $settings['title_image']['url'] ) ) : ?>
							<div class="nikobazar-product-carousel__heading-title nikobazar-product-carousel__heading-title--image">
								<img alt="<?php echo $settings['title'] ?>" src="<?php echo esc_url( $settings['title_image']['url'] ); ?>">
							</div>
						<?php endif; ?>
					<?php } elseif ( $settings['title_type'] == 'external' ) { ?>
						<?php if( ! empty( $settings['external_url'] ) ) : ?>
							<div class="nikobazar-product-carousel__heading-title nikobazar-product-carousel__heading-title--image">
								<img alt="<?php echo $settings['title'] ?>" src="<?php echo esc_url( $settings['external_url'] ); ?>">
							</div>
						<?php endif; ?>
					<?php } else { ?>
						<?php if( ! empty( $settings['title_icon']['value'] ) ) : ?>
							<div class="nikobazar-product-carousel__heading-title nikobazar-product-carousel__heading-title--icon">
								<?php Icons_Manager::render_icon( $settings['title_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</div>
						<?php endif; ?>
					<?php } ?>

					<?php if( ! empty( $settings['description'] ) ) : ?>
						<div class="nikobazar-product-carousel__heading-description"><?php echo $settings['description']; ?></div>
					<?php endif; ?>
						<?php $this->render_button(); ?>
				</div>
			<?php endif; ?>
			<?php
				if( $settings['arrows_style'] == '2' ) {
					?><div class="nikobazar-product-carousel__container"><?php
				}

				printf( '%s', $this->render_products() );

				$icon_left = $settings['arrows_icon'] == 'regular' ?  'left' : 'arrow-left-long';
				$icon_right = $settings['arrows_icon'] == 'regular' ?  'right' : 'arrow-right-long';
				echo \Nikobazar\Addons\Helper::get_svg( $icon_left, 'ui' , [ 'class' => 'nikobazar-swiper-button-prev swiper-button nikobazar-swiper-button' ]  );
				echo \Nikobazar\Addons\Helper::get_svg( $icon_right, 'ui' , [ 'class' => 'nikobazar-swiper-button-next swiper-button nikobazar-swiper-button' ] );
				echo '<div class="swiper-pagination"></div>';

				if( $settings['arrows_style'] == '2' ) {
					?></div><?php
				}
			?>
		</div>
		<?php
	}
}
