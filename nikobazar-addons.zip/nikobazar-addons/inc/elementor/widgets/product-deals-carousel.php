<?php

namespace Nikobazar\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Nikobazar\Addons\Elementor\Base\Products_Widget_Base;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Nikobazar\Addons\Helper;

use Nikobazar\Addons\Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Product Deals Carousel widget
 */
class Product_Deals_Carousel extends Products_Widget_Base {
	use \Nikobazar\Addons\Elementor\Widgets\Traits\Button_Trait;

	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nikobazar-product-deals';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Nikobazar] Product Deals Carousel', 'nikobazar-addons' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-countdown';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nikobazar-addons' ];
	}

	public function get_script_depends() {
		return [
			'nikobazar-coundown',
			'nikobazar-elementor-widgets'
		];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_content_settings_controls();
		$this->section_products_settings_controls();
		$this->section_carousel_settings_controls();
	}

	// Tab Style
	protected function section_style() {
		$this->section_content_style_controls();
		$this->section_product_style_controls();
		$this->section_carousel_style_controls();
	}

	protected function section_products_settings_controls() {
		$this->start_controls_section(
			'section_products',
			[ 'label' => esc_html__( 'Products', 'nikobazar-addons' ) ]
		);

		$this->add_control(
			'products_divider',
			[
				'label' => esc_html__( 'Products', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'limit',
			[
				'label'   => esc_html__( 'Total Products', 'nikobazar-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 10,
				'min'     => 1,
				'max'     => 50,
				'step'    => 1,
			]
		);

		$this->add_control(
			'type',
			[
				'label'     => esc_html__( 'Products', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'day'   => esc_html__( 'Deals of the day', 'nikobazar-addons' ),
					'week'  => esc_html__( 'Deals of the week', 'nikobazar-addons' ),
					'month' => esc_html__( 'Deals of the month', 'nikobazar-addons' ),
					'sale' => esc_html__( 'On Sale', 'nikobazar-addons' ),
					'deals' => esc_html__( 'Product Deals', 'nikobazar-addons' ),
					'recent' => esc_html__( 'Recent Products', 'nikobazar-addons' ),
				],
				'default'   => 'day',
				'toggle'    => false,
				'prefix_class' => 'nikobazar-product-deals__type-',
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'     => esc_html__( 'Order By', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'menu_order' => __( 'Menu Order', 'nikobazar-addons' ),
					'date'       => __( 'Date', 'nikobazar-addons' ),
					'title'      => __( 'Title', 'nikobazar-addons' ),
					'price'      => __( 'Price', 'nikobazar-addons' ),
				],
				'default'   => 'menu_order',
			]
		);

		$this->add_control(
			'order',
			[
				'label'     => esc_html__( 'Order', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''     => esc_html__( 'Default', 'nikobazar-addons' ),
					'asc'  => esc_html__( 'Ascending', 'nikobazar-addons' ),
					'desc' => esc_html__( 'Descending', 'nikobazar-addons' ),
				],
				'default'   => '',
			]
		);

		$this->add_control(
			'product_outofstock',
			[
				'label'        => esc_html__( 'Show Out Of Stock Products', 'nikobazar-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'nikobazar-addons' ),
				'label_off'    => esc_html__( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'product_cat',
			[
				'label'       => esc_html__( 'Product Categories', 'nikobazar-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'nikobazar-addons' ),
				'type'        => 'nikobazar-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_cat',
				'sortable'    => true,

			]
		);

		$this->add_control(
			'product_tag',
			[
				'label'       => esc_html__( 'Product Tags', 'nikobazar-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'nikobazar-addons' ),
				'type'        => 'nikobazar-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_tag',
				'sortable'    => true,

			]
		);

		$this->add_control(
			'product_brand',
			[
				'label'       => esc_html__( 'Product Brands', 'nikobazar-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'nikobazar-addons' ),
				'type'        => 'nikobazar-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_brand',
				'sortable'    => true,

			]
		);

		$this->add_control(
			'hide_vendor',
			[
				'label'     => esc_html__( 'Hide Vendor Name', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Show', 'nikobazar-addons' ),
				'label_on'  => __( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'none',
				'default'      => '',
				'selectors' => [
					'{{WRAPPER}} ul.products li.product .sold-by-meta' => 'display: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function section_content_settings_controls() {
		$this->start_controls_section(
			'section_content_settings',
			[ 'label' => esc_html__( 'Heading', 'nikobazar-addons' ) ]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'nikobazar-addons' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'nikobazar-addons' ),
				'default' => __( 'This is Title', 'nikobazar-addons' ),
			]
		);

		$this->add_control(
			'after_title',
			[
				'label' => __( 'After Title', 'nikobazar-addons' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
			]
		);

		$this->add_control(
			'sale_text',
			[
				'label' => __( 'Sale Text', 'nikobazar-addons' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Ends in', 'nikobazar-addons' ),
			]
		);

		$controls = [
			'button_text_label' => __( 'Button Text', 'nikobazar-addons' ),
			'button_text_label_mobile'     => __( 'Button Text Mobile', 'nikobazar-addons'),
		];

		$this->register_button_content_controls( $controls );

		$this->end_controls_section();
	}

	protected function section_carousel_settings_controls() {
		$this->start_controls_section(
			'section_carousel_settings',
			[ 'label' => esc_html__( 'Carousel Settings', 'nikobazar-addons' ) ]
		);

		$this->add_responsive_control(
			'slides_to_show',
			[
				'label'              => esc_html__( 'Slides to show', 'nikobazar-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 5,
				'frontend_available' => true,
				'separator'          => 'before',
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'label'              => esc_html__( 'Slides to scroll', 'nikobazar-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 5,
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'navigation',
			[
				'label'   => esc_html__( 'Navigation', 'nikobazar-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'arrows'    => esc_html__( 'Arrows', 'nikobazar-addons' ),
					'dots'      => esc_html__( 'Dots', 'nikobazar-addons' ),
					'scrollbar' => esc_html__( 'Scrollbar', 'nikobazar-addons' ),
					'none'      => esc_html__( 'None', 'nikobazar-addons' ),
				],
				'default'            => 'arrows',
				'toggle'             => false,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'infinite',
			[
				'label'     => __( 'Infinite Loop', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'nikobazar-addons' ),
				'label_on'  => __( 'On', 'nikobazar-addons' ),
				'default'   => '',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'     => __( 'Autoplay', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'nikobazar-addons' ),
				'label_on'  => __( 'On', 'nikobazar-addons' ),
				'default'   => '',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'speed',
			[
				'label'       => __( 'Speed', 'nikobazar-addons' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 2000,
				'min'         => 100,
				'step'        => 100,
				'description' => esc_html__( 'Slide animation speed (in ms)', 'nikobazar-addons' ),
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
	}

	protected function section_content_style_controls() {
		// Content Style
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Heading', 'nikobazar-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_position',
			[
				'label' => esc_html__( 'Heading Position', 'nikobazar-addons' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'top',
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'nikobazar-addons' ),
						'icon' => 'eicon-h-align-left',
					],
					'top' => [
						'title' => esc_html__( 'Top', 'nikobazar-addons' ),
						'icon' => 'eicon-v-align-top',
					],
				],
				'prefix_class' => 'nikobazar-product-deals-position--',
				'toggle' => false,
			]
		);

		$this->add_responsive_control(
			'heading_width',
			[
				'label'     => esc_html__( 'Width', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'     => [
					'px' => [
						'min' => 100,
						'max' => 600,
					],
				],
				'selectors' => [
					'{{WRAPPER}}.nikobazar-product-deals-position--left .nikobazar-product-deals__content' => 'width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}}.nikobazar-product-deals-position--left .nikobazar-product-deals__products' => 'width: calc( 100% - {{SIZE}}{{UNIT}} ); min-width: calc( 100% - {{SIZE}}{{UNIT}} )',
				],
				'condition' => [
					'heading_position' => 'left'
				]
			]
		);

		$this->add_responsive_control(
			'heading_padding',
			[
				'label'      => esc_html__( 'Padding', 'nikobazar-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'default'    => [],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}}.nikobazar-product-deals-position--left .nikobazar-product-deals__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'heading_position' => 'left'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'heading_border',
				'label' => esc_html__( 'Border', 'nikobazar-addons' ),
				'selector' => '{{WRAPPER}}.nikobazar-product-deals-position--left .nikobazar-product-deals__content',
				'condition' => [
					'heading_position' => 'left'
				]
			]
		);

		$this->add_control(
			'heading_title',
			[
				'label'     => esc_html__( 'Title', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .nikobazar-product-deals__title',
			]
		);

		$this->add_control(
			'heading_after_title',
			[
				'label'     => esc_html__( 'After Title', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'after_title_color',
			[
				'label' => __( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals__aftertitle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'after_title_typography',
				'selector' => '{{WRAPPER}} .nikobazar-product-deals__aftertitle',
			]
		);

		$this->add_control(
			'heading_sale_text',
			[
				'label'     => esc_html__( 'Sale text', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'sale_text_color',
			[
				'label' => __( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals__sale-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sale_text_typography',
				'selector' => '{{WRAPPER}} .nikobazar-product-deals__sale-text',
			]
		);

		$this->add_control(
			'heading_time',
			[
				'label'     => esc_html__( 'Time', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'time_bg_color',
			[
				'label' => __( 'Background Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-countdown .digits' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'time_color',
			[
				'label' => __( 'Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-countdown .digits' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'time_text_color',
			[
				'label' => __( 'Text Color', 'nikobazar-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .nikobazar-countdown .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_button',
			[
				'label'     => esc_html__( 'Button', 'nikobazar-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$controls = [
			'skin'     => 'subtle',
			'size'      => 'medium',
		];

		$this->register_button_style_controls($controls);

		$this->end_controls_section();
	}

	protected function section_product_style_controls() {
		$this->start_controls_section(
			'section_style_product',
			[
				'label' => esc_html__( 'Product', 'nikobazar-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'hide_progress_bar',
			[
				'label'        => esc_html__( 'Hide Progress Bar', 'nikobazar-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => __( 'Off', 'nikobazar-addons' ),
				'label_on'     => __( 'On', 'nikobazar-addons' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'prefix_class' => 'nikobazar-product-deals__hide-progress-bar-',
			]
		);

		$this->end_controls_section();
	}

	protected function section_carousel_style_controls() {
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Carousel', 'nikobazar-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// Arrows
		$this->add_control(
			'arrow_style_heading',
			[
				'label' => esc_html__( 'Arrows', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sliders_arrow_style',
			[
				'label'        => __( 'Option', 'nikobazar-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'nikobazar-addons' ),
				'label_on'     => __( 'Custom', 'nikobazar-addons' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			'sliders_arrows_size',
			[
				'label'     => __( 'Size', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_width',
			[
				'label'     => __( 'Width', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'default' => [ 'size' => 44, 'unit' => 'px' ],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_height',
			[
				'label'     => __( 'Height', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_spacing_horizontal',
			[
				'label'      => esc_html__( 'Horizontal Position', 'nikobazar-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => -100,
						'max' => 1000,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button-next' => 'left: {{SIZE}}{{UNIT}}; right: auto;',
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button-prev' => 'left: calc( 220px + {{SIZE}}{{UNIT}} );',
					'.rtl {{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button-prev' => 'right: calc( 220px + {{SIZE}}{{UNIT}} ); left: auto;',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_spacing_vertical',
			[
				'label'      => esc_html__( 'Vertical Position', 'nikobazar-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => -100,
						'max' => 1000,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button-prev' => 'top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button-next' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_popover();

		$this->add_control(
			'sliders_arrow_color',
			[
				'label'     => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrow_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .nikobazar-swiper-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'sliders_arrow_box_shadow',
				'label' => __( 'Box Shadow', 'nikobazar-addons' ),
				'selector' => '{{WRAPPER}} .nikobazar-swiper-button',
			]
		);

		// Dots
		$this->add_control(
			'dots_style_heading',
			[
				'label' => esc_html__( 'Dots', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sliders_dots_style',
			[
				'label'        => __( 'Option', 'nikobazar-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'nikobazar-addons' ),
				'label_on'     => __( 'Custom', 'nikobazar-addons' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			'sliders_dots_gap',
			[
				'label'     => __( 'Gap', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-pagination-bullet' => 'margin: 0 {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_dots_size',
			[
				'label'     => __( 'Size', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_dots_offset_ver',
			[
				'label'     => esc_html__( 'Spacing Top', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => -100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_popover();

		$this->add_control(
			'sliders_dots_bgcolor',
			[
				'label'     => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-pagination-bullet' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'sliders_dots_ac_bgcolor',
			[
				'label'     => esc_html__( 'Color Active', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-pagination-bullet-active' => 'background-color : {{VALUE}};',
				],
			]
		);

		// Scrollbar
		$this->add_control(
			'scrollbar_style_heading',
			[
				'label' => esc_html__( 'Scrollbar', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'scrollbar_color',
			[
				'label'     => esc_html__( 'Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-scrollbar' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'scrollbar_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'nikobazar-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-scrollbar-drag' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'scrollbar_spacing',
			[
				'label'     => __( 'Spacing', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 150,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .nikobazar-product-deals .swiper-scrollbar' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$nav        = $settings['navigation'];
		$nav_tablet = empty( $settings['navigation_tablet'] ) ? $nav : $settings['navigation_tablet'];
		$nav_mobile = empty( $settings['navigation_mobile'] ) ? $nav : $settings['navigation_mobile'];

		$classes = [
			'nikobazar-product-deals nikobazar-swiper-carousel-elementor nikobazar-product-carousel',
			'navigation-' . $nav,
			'navigation-tablet-' . $nav_tablet,
			'navigation-mobile-' . $nav_mobile,
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		if ( ! empty( $settings['primary_mobile_button_text'] ) ) {
			$this->add_render_attribute( 'wrapper', 'class', [ 'nikobazar-product-deals__button-mobile-on' ] );
		}

		echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) .'>';

		$atts = array(
			'type'           => isset( $settings['type'] ) ?  $settings['type']  : '',
			'columns'        => isset( $settings['slides_to_show'] ) ? intval( $settings['slides_to_show'] ). ' swiper-wrapper': '',
			'category'       => isset( $settings['product_cat'] ) ? $settings['product_cat'] : '',
			'tag'            => isset( $settings['product_tag'] ) ? $settings['product_tag'] : '',
			'products'       => isset( $settings['products'] ) ? $settings['products'] : '',
			'order'          => isset( $settings['order'] ) ? $settings['order'] : '',
			'orderby'        => isset( $settings['orderby'] ) ? $settings['orderby'] : '',
			'per_page'       => isset( $settings['limit'] ) ? intval( $settings['limit'] ) : '',
			'product_brands' => isset( $settings['product_brand'] ) ? $settings['product_brand'] : '',
			'nikobazar_soldbar'	 => isset( $settings['hide_progress_bar'] ) && $settings['hide_progress_bar'] == 'yes'  ?  false  : true,
		);

		if ( isset( $settings['product_outofstock'] ) && empty( $settings['product_outofstock'] ) ) {
			$atts['product_outofstock'] = $settings['product_outofstock'];
		}

		$product_ids = Utils::products_shortcode( $atts );

		$product_ids = ! empty($product_ids) ? $product_ids['ids'] : 0;

		if( ! $product_ids ) {
			return;
		}

		$sale_text = ! empty( $settings['sale_text'] ) ? '<div class="nikobazar-product-deals__sale-text">' . $settings['sale_text'] . '</div>' : '';

		//time
		$dataText = $this->get_countdown_texts();

		$now         = strtotime( current_time( 'Y-m-d H:i:s' ) );
		$expire_date = 0;
		if ( $settings['type'] == 'day' ) {
			$expire_date = strtotime( '00:00 +1 day', $now );
		} elseif ( $settings['type'] == 'week' ) {
			$expire_date = strtotime( '00:00 next monday', $now );
		} elseif ( $settings['type'] == 'month' ) {
			$expire_date = strtotime( '00:00 first day of next month', $now );
		}
		$expire            =  $expire_date ? $expire_date - $now : '';


		$this->add_render_attribute( 'countdown', 'data-expire', $expire );
		$this->add_render_attribute( 'countdown', 'data-text', wp_json_encode( $dataText ) );

		$countdown = $expire ? sprintf( '<div class="nikobazar-product-deals__countdown" >' . $sale_text . '<div class="nikobazar-countdown" %s></div></div>', $this->get_render_attribute_string( 'countdown' ) ) : '' ;

		$output_pagination =  \Nikobazar\Addons\Helper::get_svg( 'left', 'ui' , [ 'class' => 'nikobazar-swiper-button-prev swiper-button nikobazar-swiper-button' ]  );
		$output_pagination .=  \Nikobazar\Addons\Helper::get_svg( 'right', 'ui' , [ 'class' => 'nikobazar-swiper-button-next swiper-button nikobazar-swiper-button' ] );
		$output_pagination .= '<div class="nikobazar-swiper-carousel__paginations swiper-pagination"></div>';

		if ( ! empty( $settings['title'] ) || ! empty( $settings['after_title'] ) || ! empty( $countdown ) ||  ! empty( $settings['primary_button_text'] ) ||  ! empty( $settings['primary_mobile_button_text'] ) ){
			?>
			<div class="nikobazar-product-deals__content">
				<?php echo ! empty( $settings['title'] ) ? '<div class="nikobazar-product-deals__title">' . $settings['title'] . '</div>' : ''; ?>
				<?php echo ! empty( $settings['after_title'] ) ? '<div class="nikobazar-product-deals__aftertitle">' . $settings['after_title'] . '</div>' : ''; ?>
				<div class="nikobazar-product-deals__group-heading">
					<?php echo $countdown; ?>
					<span class="nikobazar-product-deals__button">
						<?php $this->render_button(); ?>
					</span>
				</div>
			</div>
			<?php
		}

		ob_start();

		wc_setup_loop(
			array(
				'columns' => $atts['columns']
			)
		);

		$this->get_template_loop( $product_ids );

		$products = ob_get_clean();

		echo sprintf(
			'<div class="nikobazar-product-deals__products swiper"> %s </div> %s',
			$products,
			$output_pagination,
		);

		echo '</div>';
	}

	/**
	 * Loop over products
	 *
	 * @since 1.0.0
	 *
	 * @param string
	 */
	protected function get_template_loop( $products_ids, $template = 'product' ) {
		update_meta_cache( 'post', $products_ids );
		update_object_term_cache( $products_ids, 'product' );

		$original_post = $GLOBALS['post'];

		woocommerce_product_loop_start();

		foreach ( $products_ids as $product_id ) {
			$GLOBALS['post'] = get_post( $product_id ); // WPCS: override ok.
			setup_postdata( $GLOBALS['post'] );
			wc_get_template_part( 'content', $template );
		}

		$GLOBALS['post'] = $original_post; // WPCS: override ok.

		woocommerce_product_loop_end();

		wp_reset_postdata();
		wc_reset_loop();
	}

	/**
	 * Functions that used to get coutndown texts
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public static function get_countdown_texts() {
		return apply_filters( 'nikobazar_get_countdown_texts', array(
			'weeks'    => esc_html__( 'Weeks', 'nikobazar-addons' ),
			'days'    => esc_html__( 'Days', 'nikobazar-addons' ),
			'hours'   => esc_html__( 'Hours', 'nikobazar-addons' ),
			'minutes' => esc_html__( 'Mins', 'nikobazar-addons' ),
			'seconds' => esc_html__( 'Secs', 'nikobazar-addons' )
		) );
	}

}