<?php

namespace Nikobazar\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Nikobazar\Addons\Elementor\Base\Products_Widget_Base;
use Nikobazar\Addons\Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Product Deals Grid widget
 */
class Product_Grid extends Products_Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nikobazar-product-grid';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[Nikobazar] Products Grid', 'nikobazar-addons' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nikobazar-addons' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_products_settings_controls();
		$this->section_pagination_settings_controls();
	}

	// Tab Style
	protected function section_style() {
		$this->section_product_style_controls();
	}

	protected function section_products_settings_controls() {
		$this->start_controls_section(
			'section_products',
			[ 'label' => esc_html__( 'Products', 'nikobazar-addons' ) ]
		);

		$this->add_control(
			'products_divider',
			[
				'label' => esc_html__( 'Products', 'nikobazar-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'limit',
			[
				'label'   => esc_html__( 'Total Products', 'nikobazar-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 16,
				'min'     => 1,
				'max'     => 50,
				'step'    => 1,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'columns',
			[
				'label'     => esc_html__( 'Column', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'1' => esc_html__( '1', 'nikobazar-addons' ),
					'2' => esc_html__( '2', 'nikobazar-addons' ),
					'3' => esc_html__( '3', 'nikobazar-addons' ),
					'4' => esc_html__( '4', 'nikobazar-addons' ),
					'5' => esc_html__( '5', 'nikobazar-addons' ),
					'6' => esc_html__( '6', 'nikobazar-addons' ),
				],
				'default'   => '4',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'products',
			[
				'label'     => esc_html__( 'Product', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'recent'       => esc_html__( 'Recent', 'nikobazar-addons' ),
					'featured'     => esc_html__( 'Featured', 'nikobazar-addons' ),
					'best_selling' => esc_html__( 'Best Selling', 'nikobazar-addons' ),
					'top_rated'    => esc_html__( 'Top Rated', 'nikobazar-addons' ),
					'sale'         => esc_html__( 'On Sale', 'nikobazar-addons' ),
					'custom'         => esc_html__( 'Custom', 'nikobazar-addons' ),
				],
				'default'   => 'recent',
				'toggle'    => false,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'     => esc_html__( 'Order By', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'menu_order' => __( 'Menu Order', 'nikobazar-addons' ),
					'date'       => __( 'Date', 'nikobazar-addons' ),
					'title'      => __( 'Title', 'nikobazar-addons' ),
					'price'      => __( 'Price', 'nikobazar-addons' ),
				],
				'condition' => [
					'products'            => [ 'top_rated', 'sale', 'featured' ],
				],
				'default'   => 'date',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'order',
			[
				'label'     => esc_html__( 'Order', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''     => esc_html__( 'Default', 'nikobazar-addons' ),
					'asc'  => esc_html__( 'Ascending', 'nikobazar-addons' ),
					'desc' => esc_html__( 'Descending', 'nikobazar-addons' ),
				],
				'condition' => [
					'products'            => [ 'top_rated', 'sale', 'featured' ],
				],
				'default'   => '',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'ids',
			[
				'label' => __( 'Products', 'nikobazar-addons' ),
				'type' => 'nikobazar-autocomplete',
				'placeholder' => esc_html__( 'Click here and start typing...', 'nikobazar-addons' ),
				'default' => '',
				'multiple'    => true,
				'source'      => 'product',
				'sortable'    => true,
				'label_block' => true,
				'condition' => [
					'products' => ['custom']
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'product_cat',
			[
				'label'       => esc_html__( 'Product Categories', 'nikobazar-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'nikobazar-addons' ),
				'type'        => 'nikobazar-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_cat',
				'sortable'    => true,
				'frontend_available' => true,

			]
		);

		$this->add_control(
			'product_tag',
			[
				'label'       => esc_html__( 'Product Tags', 'nikobazar-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'nikobazar-addons' ),
				'type'        => 'nikobazar-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_tag',
				'sortable'    => true,
				'frontend_available' => true,

			]
		);

		$this->add_control(
			'product_brand',
			[
				'label'       => esc_html__( 'Product Brands', 'nikobazar-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'nikobazar-addons' ),
				'type'        => 'nikobazar-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_brand',
				'sortable'    => true,
				'frontend_available' => true,

			]
		);

		$this->add_control(
			'product_outofstock',
			[
				'label'        => esc_html__( 'Show Out Of Stock Products', 'nikobazar-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'nikobazar-addons' ),
				'label_off'    => esc_html__( 'Hide', 'nikobazar-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'frontend_available' => true,
			]
		);


		$this->end_controls_section();
	}

	protected function section_pagination_settings_controls() {
		$this->start_controls_section(
			'section_pagination_settings',
			[ 'label' => esc_html__( 'Pagination', 'nikobazar-addons' ) ]
		);

		$this->add_control(
			'pagination',
			[
				'label'   => esc_html__( 'Pagination', 'nikobazar-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'none'     => esc_html__( 'None', 'nikobazar-addons' ),
					'numberic' => esc_html__( 'Numberic', 'nikobazar-addons' ),
					'infinite' => esc_html__( 'Infinite Scroll', 'nikobazar-addons' ),
				],
				'default'            => 'none',
			]
		);

		$this->end_controls_section();
	}

	protected function section_product_style_controls() {
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'nikobazar-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'pagination_spacing',
			[
				'label'        => esc_html__( 'Pagination Spacing', 'nikobazar-addons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'size' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_products',
			[
				'label' => esc_html__( 'Products', 'nikobazar-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'products_border',
			[
				'label'     => esc_html__( 'Border', 'nikobazar-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''                  => esc_html__( 'No Border', 'nikobazar-addons' ),
					'has-border'        => esc_html__( 'Border', 'nikobazar-addons' ),
					'has-border-bottom' => esc_html__( 'Border Bottom Only', 'nikobazar-addons' ),
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$products_border = ! empty( $settings['products_border'] ) ? 'catalog-grid--' . $settings['products_border'] : '';
		$classes = [
			'nikobazar-product-grid' . ' ' . $products_border,
		];

		$attr = [
			'type' 			=> $settings['products'],
			'orderby'  			=> $settings['orderby'],
			'order'    			=> $settings['order'],
			'category'    		=> $settings['product_cat'],
			'tag'    			=> $settings['product_tag'],
			'product_brands'    => $settings['product_brand'],
			'ids'    => $settings['ids'],
			'limit'    			=> $settings['limit'],
			'columns'    		=> $settings['columns'],
			'paginate'			=> true,
		];

		if ( isset( $settings['product_outofstock'] ) && empty( $settings['product_outofstock'] ) ) {
			$attr['product_outofstock'] = $settings['product_outofstock'];
		}

		$results = Utils::products_shortcode( $attr );
		if ( ! $results ) {
			return;
		}

		$results_ids = ! empty($results['ids']) ? $results['ids'] : 0;

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) .'>';

		wc_setup_loop(
			array(
				'columns'      => $settings['columns']
			)
		);

		Utils::get_template_loop( $results_ids );

		if ( $settings['pagination'] == 'numberic' ) {
			self::get_pagination( $results['total_pages'], $results['current_page'] );
		} elseif ( $settings['pagination'] == 'infinite' ) {
			if ( $results['current_page'] < $results['total_pages']  ) {
				echo sprintf(
					'<a href="#" class="woocommerce-pagination ajax-load-products %s" data-page="%s" rel="nofollow">
						<div class="nikobazar-pagination--loading">
							<div class="nikobazar-pagination--loading-dots">
								<span></span>
								<span></span>
								<span></span>
								<span></span>
							</div>
							<div class="nikobazar-pagination--loading-text">%s</div>
						</div>
					</a>',
					$settings['pagination'] == 'infinite' ? 'ajax-infinite' : '',
					esc_attr( $results['current_page'] + 1 ),
					esc_html__('Loading more...', 'nikobazar-addons')
				);
			}
		}
		echo '</div>';
	}

	/**
	 * Products pagination.
	 */
	public static function get_pagination( $total_pages, $current_page ) {
		echo '<nav class="woocommerce-pagination">';
		echo paginate_links(
			array( // WPCS: XSS ok.
				'base'      => esc_url_raw( add_query_arg( 'product-page', '%#%', false ) ),
				'format'    => '?product-page=%#%',
				'add_args'  => false,
				'current'   => max( 1, $current_page ),
				'total'     => $total_pages,
				'prev_text' => \Nikobazar\Addons\Helper::get_svg( 'left', 'ui', 'class=nikobazar-pagination__arrow' ),
				'next_text' => \Nikobazar\Addons\Helper::get_svg( 'right', 'ui', 'class=nikobazar-pagination__arrow' ),
				'type'      => 'list',
			)
		);
		echo '</nav>';
	}


}