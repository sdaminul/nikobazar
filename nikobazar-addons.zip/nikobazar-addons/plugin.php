<?php
/**
 * Nikobazar Addons init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Nikobazar
 */

namespace Nikobazar;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Nikobazar Addons init
 *
 * @since 1.0.0
 */
class Addons {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_templates' ) );

		add_action( 'init', array( $this, 'create_product_brand' ) );
	}

	/**
	 * Load Templates
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function load_templates() {
		$this->includes();
		spl_autoload_register( '\Nikobazar\Addons\Auto_Loader::load' );

		$this->add_actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		// Auto Loader
		require_once MOTTA_ADDONS_DIR . 'autoloader.php';
		\Nikobazar\Addons\Auto_Loader::register( [
			'Nikobazar\Addons\Helper'         => MOTTA_ADDONS_DIR . 'inc/helper.php',
			'Nikobazar\Addons\Theme_Builder'  => MOTTA_ADDONS_DIR . 'inc/backend/theme-builder.php',
			'Nikobazar\Addons\Theme_Settings' => MOTTA_ADDONS_DIR . 'inc/backend/theme-settings.php',
			'Nikobazar\Addons\User'       	  => MOTTA_ADDONS_DIR . 'inc/backend/user.php',
			'Nikobazar\Addons\Importer'      => MOTTA_ADDONS_DIR . 'inc/backend/importer.php',
			'Nikobazar\Addons\Product_Brands' => MOTTA_ADDONS_DIR . 'inc/backend/product-brand.php',
			'Nikobazar\Addons\Widgets'        => MOTTA_ADDONS_DIR . 'inc/widgets/widgets.php',
			'Nikobazar\Addons\Modules'        => MOTTA_ADDONS_DIR . 'modules/modules.php',
			'Nikobazar\Addons\Elementor'      => MOTTA_ADDONS_DIR . 'inc/elementor/elementor.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function add_actions() {
		// Before init action.
		do_action( 'before_nikobazar_init' );

		$this->get( 'theme_builder' );
		$this->get( 'theme_settings' );
		$this->get( 'user' );

		// Widgets
		$this->get( 'widgets' );

		// Modules
		$this->get( 'modules' );

		// Elementor
		$this->get( 'elementor' );

		$this->get( 'importer' );

		// Init action.
		do_action( 'after_nikobazar_init' );
	}

	public function create_product_brand() {
		$this->get( 'product-brand' );
	}

	/**
	 * Get Nikobazar Addons Class instance
	 *
	 * @since 1.0.0
	 *
	 * @return object
	 */
	public function get( $class ) {
		switch ( $class ) {
			case 'theme_builder':
				if ( defined( 'ELEMENTOR_VERSION' ) ) {
					return \Nikobazar\Addons\Theme_Builder::instance();
				}
				break;

			case 'theme_settings':
				return \Nikobazar\Addons\Theme_Settings::instance();
				break;

			case 'user':
				return \Nikobazar\Addons\User::instance();
				break;

			case 'product-brand':
				return \Nikobazar\Addons\Product_Brands::instance();
				break;

			case 'importer':
				if( is_admin() ) {
					return \Nikobazar\Addons\Importer::instance();
				}
				break;

			case 'widgets':
				return \Nikobazar\Addons\Widgets::instance();
				break;

			case 'modules':
				return \Nikobazar\Addons\Modules::instance();
				break;

			case 'elementor':
				if ( defined( 'ELEMENTOR_VERSION' ) ) {
					return \Nikobazar\Addons\Elementor::instance();
				}
				break;

			default:
				break;
		}
	}
}
