Plugin SW WooCommerce Catalog



== author: wpthemego

== Author Link: http://www.nikobazar.com/

== Description: A plugin help to display your woocommerce site as a catalog site.